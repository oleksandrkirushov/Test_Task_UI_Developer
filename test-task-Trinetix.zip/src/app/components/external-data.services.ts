import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class ExternalData {
    constructor(private httpExternalData: HttpClient) {}
    
    getExternalData(){
    return this.httpExternalData.get('https://api.giphy.com/v1/gifs/${searchValue}?api_key=jRfm1eOkIA2CdOd25ahwGR0IepZtvTmx&limit=${limit}&offset=${offset}&rating=g');
}}
